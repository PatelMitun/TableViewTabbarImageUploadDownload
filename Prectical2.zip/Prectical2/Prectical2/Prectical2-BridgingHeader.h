//
//  Prectical2-BridgingHeader.h
//  Prectical2
//
//  Created by Apple on 24/09/17.
//  Copyright © 2017 Apple. All rights reserved.
//

#ifndef Prectical2_BridgingHeader_h
#define Prectical2_BridgingHeader_h

#import <sqlite3.h>

#endif /* Prectical2_BridgingHeader_h */
