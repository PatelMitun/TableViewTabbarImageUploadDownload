//
//  UserListVCCell.swift
//  Prectical2
//
//  Created by Apple on 24/09/17.
//  Copyright © 2017 Apple. All rights reserved.
//

import UIKit
import SDWebImage

class UserListVCCell: UITableViewCell {

    @IBOutlet weak var IBlblTitle: UILabel!
    @IBOutlet weak var IBlblStatus: UILabel!
    @IBOutlet weak var IBimgPost: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setCustomCell(objModel: PostDetail) {
        
        if let strname = objModel.Description {
            self.IBlblTitle.text = strname
        }
        self.IBlblStatus.text = "New Arrival"
        
        if let strImageUrl = objModel.PostImagePath, strImageUrl != "" {
            print(strImageUrl)
            self.IBimgPost.setIndicatorStyle(.white)
            self.IBimgPost.setShowActivityIndicator(true)
            self.IBimgPost.sd_setImage(with: URL(string:strImageUrl), placeholderImage: UIImage(named: AppImageName.Img_Placeholder_Post))
        }
    }
}
