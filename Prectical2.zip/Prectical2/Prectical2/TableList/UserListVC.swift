//
//  UserListVC.swift
//  Prectical2
//
//  Created by Apple on 23/09/17.
//  Copyright © 2017 Apple. All rights reserved.
//

import UIKit

class UserListVC: UIViewController {

    @IBOutlet weak var IBtblList: UITableView!
    @IBOutlet weak var IBbtnbarBack: UIBarButtonItem!
    var PageSize :Int                   = 5
    var PageIndex :Int                  = 1
    var objPostList:PostModel           = PostModel<PostDetail>()
    var refreshControl: UIRefreshControl!
    var IsFromTabbar: Bool = false
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.setView()
        self.getPostList(IsLoader: true, PageIndex: PageIndex)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnbarBack(_ sender: Any)
    {
        if IsFromTabbar {
            let objTabbarVC = ViewController(nibName: "ViewController", bundle: nil)
            appDelegate.window?.rootViewController = objTabbarVC
            appDelegate.window?.makeKeyAndVisible()
        }
        else {
            self.navigationController?.popViewController(animated: true)
        }
    }
}

//MARK: Custom Method
extension UserListVC {
    
    func setView() {
        if IsFromTabbar {
            self.navigationController?.navigationItem.leftBarButtonItem = IBbtnbarBack
        }
        self.objPostList.Items = []
        self.IBtblList.register(UINib(nibName: "UserListVCCell", bundle: nil), forCellReuseIdentifier: "UserListVCCell")
        self.refreshControl = UIRefreshControl()
        self.refreshControl.attributedTitle = NSAttributedString(string: "")
        self.refreshControl.addTarget(self, action: #selector(self.pullToRefresh(sender:)), for: UIControlEvents.valueChanged)
        self.IBtblList.insertSubview(self.refreshControl, at: 0)
        self.IBtblList.tableFooterView = UIView()
    }
    
    func pullToRefresh(sender:AnyObject) {
        refreshControl.beginRefreshing()
        self.PageIndex                  = 1
        self.getPostList(IsLoader: false, PageIndex: PageIndex)
    }
}

extension UserListVC: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (self.objPostList.Items?.count)!
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell: UserListVCCell? = tableView.dequeueReusableCell(withIdentifier: "UserListVCCell") as? UserListVCCell
        if cell == nil {
            let nib : NSArray = Bundle.main.loadNibNamed("UserListVCCell", owner: self, options: nil)! as NSArray
            cell = nib.object(at: 0) as? UserListVCCell
        }
        if let objItem = self.objPostList.Items?[indexPath.row] {
            cell?.setCustomCell(objModel: objItem)
        }
        return cell!
    }

}

extension UserListVC  : UIScrollViewDelegate{
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        if((self.objPostList.Items)?.isEmpty != nil){
            if((self.objPostList.Items?.count)! > 0) {
                let visiblePaths: [AnyObject] = IBtblList.indexPathsForVisibleRows! as [AnyObject]
                let lastRow: NSIndexPath = visiblePaths.last as AnyObject! as! NSIndexPath
                let numberOfSections: Int = IBtblList.numberOfSections
                let lastRowSection: Int = lastRow.section
                let lastRowRow: Int = lastRow.row
                let numberOfRowsInSection: Int = IBtblList.numberOfRows(inSection: lastRowSection)
                if lastRowSection == numberOfSections - 1 && lastRowRow == numberOfRowsInSection - 1 {
                    
                    if (PageIndex * PageSize < (self.objPostList.TotalItems)) {
                        PageIndex = PageIndex + 1
//                        self.IBtblPostList.tableFooterView = ActivityIndicatorInTableView().footerShow(tableView: IBtblList)
                        self.getPostListwithPagging(IsLoader: false, PageIndex: PageIndex)
                        
                    }
                }
            }
        }
    }
}


//Service Call Method
extension UserListVC {
    
    func getPostList(IsLoader:Bool? = true,PageIndex : Int){
        
        let objPostsRequest                 = PostsRequestModel<SearchParams>()
        objPostsRequest.PageIndex           = PageIndex
        objPostsRequest.PageSize            = self.PageSize
        let objSearchParams                 = SearchParams()
//        objSearchParams.SiteID              = Preference.GetInteger(key : UserDefaultsKey.SiteID)
        objPostsRequest.SearchParams        = objSearchParams
        
        
        let objwebservice = webService()
        objwebservice.getPostList(objPostsRequestModel: objPostsRequest, IsLoader: true, viewController: self) { (response, IsSuccess) -> Void in
            if IsSuccess! {
                if let objData = response, let objserviceData = objData.Data {
                    self.objPostList = objserviceData
                    self.IBtblList.reloadData()
                }
            }
        }
    }
    
    func getPostListwithPagging(IsLoader:Bool? = true,PageIndex : Int){
        
        let objPostsRequest                 = PostsRequestModel<SearchParams>()
        objPostsRequest.PageIndex           = PageIndex
        objPostsRequest.PageSize            = self.PageSize
        let objSearchParams                 = SearchParams()
        //        objSearchParams.SiteID              = Preference.GetInteger(key : UserDefaultsKey.SiteID)
        objPostsRequest.SearchParams        = objSearchParams
        
        
        let objwebservice = webService()
        objwebservice.getPostList(objPostsRequestModel: objPostsRequest, IsLoader: true, viewController: self) { (response, IsSuccess) -> Void in
            self.refreshControl.endRefreshing()
            if IsSuccess! {
                if let objData = response, let objserviceData = objData.Data {
                    
                    for i in 0..<(objserviceData.Items?.count)!{
                        self.objPostList.Items?.append((response?.Data?.Items?[i])!)
                    }
                    self.IBtblList.reloadData()
                }
            }
            
        }
    }
}




