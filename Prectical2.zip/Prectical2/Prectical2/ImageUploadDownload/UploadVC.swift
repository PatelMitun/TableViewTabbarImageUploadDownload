//
//  UploadVC.swift
//  Prectical2
//
//  Created by Apple on 25/09/17.
//  Copyright © 2017 Apple. All rights reserved.
//

import UIKit
import Alamofire
import SDWebImage
import AlamofireObjectMapper
import ObjectMapper


class UploadVC: UIViewController {

    @IBOutlet weak var btnUpload: UIButton!
    @IBOutlet weak var imgUpload: UIImageView!
    @IBOutlet weak var imgPreview: UIImageView!
    var image: UIImage? = nil
    override func viewDidLoad() {
        super.viewDidLoad()

        if image != nil {
            self.imgUpload.image = image
        }
        self.imgPreview.isHidden = true
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func uploadImage(_ sender:Any) {
        
        
        if(Reachability.isConnectedToNetwork())
        {
            ProgressHUD.startLoading(onView: (self.view))
            
            var imageData: [Data] = []
            
            let imageData1 = UIImageJPEGRepresentation(self.imgUpload.image!, 1.0) as! Data
            imageData.append(imageData1)
            
            var parameter : NSDictionary = NSDictionary()
            parameter = ["UserID":"81"
                ,"Token":"d5be5ea7-71a7-4307-b9ea-96fd8e672dc0"
                ,"ProductImageID":"0"
                ,"Key":"SiteAdminAppkey"] as [String:String] as NSDictionary
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                
                for i in 0..<(imageData.count){
                    multipartFormData.append(imageData[i] as Data, withName: "photo_path", fileName: "uploaded_file.jpeg", mimeType: "image/jpeg")
                }
                
                for (key, value) in parameter {
                    multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key as! String )
                }
                
                //  print("mutlipart 2st \(multipartFormData)")
            }, to:"http://admin.morecustomersapp.com/siteadminapp/api/SiteAdminProduct/AddProductImages")
            { (result) in
                switch result {
                case .success(let upload, _, _):
                    
                    upload.uploadProgress(closure: { (Progress) in
                        //                        if let view = viewController as? CreateProductImageVC {
                        //                            view.IBimgProgress.isHidden = false
                        ////                            print("Progress : \(Float(Progress.fractionCompleted))")
                        //                            view.IBimgProgress.setProgress(Float(Progress.fractionCompleted), animated: true)
                        //                        }
                    })
                    upload.responseJSON { response in
                        //                        if let view = viewController as? CreateProductImageVC {
                        //                            view.IBimgProgress.isHidden = true
                        //                            view.IBConstProgress.constant = 0
                        //                            view.IBimgProgress.progress = 0.0
                        //                        }
                        
                        
                        if(response.result.isSuccess){
                            let datastring = NSString(data:response.data!, encoding:String.Encoding.utf8.rawValue) as String?
                            let serviceresponse = Mapper<ServiceResponseArray<ProductImageModel>>().map(JSONString: datastring!)
                            if let strimagePathlist = serviceresponse?.Data, strimagePathlist.count > 0 {
                                self.setpriviewImage(strImagePath: strimagePathlist[0].FullImagePath!)
                            }

                        }else{
                            //                            print(response.result.error?.localizedDescription as Any)
                            let serviceReponse = ServiceResponseMessage()

                            serviceReponse?.IsSuccess = false
                            serviceReponse?.Message = (response.result.error?.localizedDescription)! as String
                            print(serviceReponse)
                        }
                        ProgressHUD.stopLoading(fromView: self.view)
                    }
                case .failure(let encodingError):
                    //self.delegate?.showFailAlert()
                    print(encodingError)
                }
            }
        } else {
            print("No InterNet")
        }
    }
    
    func setpriviewImage(strImagePath:String) {
        self.imgPreview.setIndicatorStyle(.white)
        self.imgPreview.setShowActivityIndicator(true)
        self.imgPreview.sd_setImage(with: URL(string: strImagePath), placeholderImage: UIImage(named: AppImageName.Img_Placeholder_Post))
        self.imgPreview.isHidden = false
    }
}
