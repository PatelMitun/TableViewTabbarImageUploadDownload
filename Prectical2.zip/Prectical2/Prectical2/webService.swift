//
//  webService.swift
//  Prectical2
//
//  Created by Apple on 24/09/17.
//  Copyright © 2017 Apple. All rights reserved.
//

import Foundation
import SystemConfiguration
import Alamofire
import AlamofireObjectMapper
import ObjectMapper

class webService: NSObject {
    
    func getPostList (objPostsRequestModel : PostsRequestModel<SearchParams>,IsLoader:Bool? = true, viewController:UIViewController? = nil, ServiceCallBack: @escaping (_ response: ServiceResponse<PostModel<PostDetail>>?, _ IsSuccess: Bool?)-> Void! ) {
        
        let serviceRequest = ServiceRequest<PostsRequestModel<SearchParams>>()
        serviceRequest.Data = objPostsRequestModel
        let JSONString = Mapper().toJSON(serviceRequest)
        
        if IsLoader == true {
            if viewController != nil {
                ProgressHUD.startLoading(onView: (viewController?.view)!)
            } else {
                ProgressHUD.startLoading(onView: appDelegate.window!)
            }
        }
        
        serviceCall.servicecall(IsLoader: IsLoader, url: serviceURL.PostList, HttpMethod: .post, InputParameter: JSONString, viewController: viewController) { (result, response) in

            print("URL: ",serviceURL.PostList)
            print("Request: ",JSONString)
            if let strResult = result {
                
                let jsonDictionary:NSDictionary = self.convertToDictionary(text: strResult)!
                print("Response: ",jsonDictionary)
            }
            
            if IsLoader == true {
                if viewController != nil {
                    ProgressHUD.stopLoading(fromView: (viewController?.view)!)
                } else {
                    ProgressHUD.stopLoading(fromView: appDelegate.window!)
                }
            }
            
            if response.IsSuccess == true {
                let serviceResponse = Mapper<ServiceResponse<PostModel<PostDetail>>>().map(JSONString: result!)
                ServiceCallBack(serviceResponse!, true)
            }
            else {
                ServiceCallBack(nil, false)
            }
        }
    }
    
    
    
    
    
    func convertToDictionary(text: String) -> NSDictionary? {
        if let data = text.data(using: .utf8) {
            do {
                return try JSONSerialization.jsonObject(with: data, options: []) as? NSDictionary
            } catch {
                print(error.localizedDescription)
            }
        }
        return nil
    }
}


class serviceCall: NSObject {
    
    class func servicecall(IsLoader:Bool? = true, url: String, HttpMethod: HTTPMethod, InputParameter: Parameters, viewController:UIViewController? = nil, ServiceCallBack: @escaping (_ result: String?, _ response: ServiceResponseMessage)-> Void) {
        
        Alamofire.request(url, method:.post,parameters:InputParameter, encoding:JSONEncoding.default, headers: nil).responseJSON { response in
            
            if(response.result.isSuccess){
                
                let datastring = NSString(data:response.data!, encoding:String.Encoding.utf8.rawValue) as String?
                //                    print("ResponseString:",datastring)
                //                    let jsonDictionary =  JSONData().onvertToDictionary(text: datastring!) as NSDictionary!
                //                    print("Response : ", jsonDictionary as Any)
                let serviceresponse = Mapper<ServiceResponseMessage>().map(JSONString: datastring!)
                //                    let str = Mapper().toJSONString(serviceresponse, prettyPrint: true)
                //                    print(serviceresponse?.description)
                ServiceCallBack(datastring, serviceresponse!)
                
            }else{
                //                    print(response.result.error?.localizedDescription as Any)
                let serviceReponse = ServiceResponseMessage()
                serviceReponse?.IsSuccess = false
                serviceReponse?.Message = (response.result.error?.localizedDescription)! as String
                ServiceCallBack(nil, serviceReponse!)
            }
            
            
        }
        
    }
}



class ProgressHUD: NSObject {
    
    class func startLoading(onView view:UIView){
        stopLoading(fromView: view)
        let activity = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.gray)
        view.addSubview(activity)
        
        activity.translatesAutoresizingMaskIntoConstraints = false
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-(leadingTrailing)-[activity]-(leadingTrailing)-|", options: NSLayoutFormatOptions(rawValue: 0), metrics: ["leadingTrailing":-8], views: ["activity":activity]))
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-(leadingTrailing)-[activity]-(leadingTrailing)-|", options: NSLayoutFormatOptions(rawValue: 0), metrics: ["leadingTrailing":-8], views: ["activity":activity]))
        
        activity.backgroundColor = UIColor.white.withAlphaComponent(0.3)
        activity.startAnimating()
        
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
    }
    
    class func stopLoading(fromView view:UIView){
        for subView in view.subviews{
            if subView.isKind(of: UIActivityIndicatorView.self){
                (subView as! UIActivityIndicatorView).stopAnimating()
                (subView as! UIActivityIndicatorView).removeFromSuperview()
                
                UIApplication.shared.isNetworkActivityIndicatorVisible = false
            }
        }
    }
    
}


public class Reachability {
    class func isConnectedToNetwork() -> Bool {
        var zeroAddress = sockaddr_in()
        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)
        //        let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
        //            SCNetworkReachabilityCreateWithAddress(nil, UnsafePointer($0))
        //        }
        let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {zeroSockAddress in
                SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
            }
        }
        var flags = SCNetworkReachabilityFlags()
        if !SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) {
            return false
        }
        let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
        let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
        return (isReachable && !needsConnection)
    }
}

class ActivityIndicatorInTableView{
    
    var container: UIView = UIView()
    var loadingView: UIView = UIView()
    var activityIndicator: UIActivityIndicatorView!
    
    //MARK: TableFooter Indicator
    func footerShow(tableView:UITableView) -> UIView{
        
        if activityIndicator != nil && activityIndicator.isAnimating == true {
            hiddeActivityIndicator()
        }
        let noData = UIView(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(tableView.bounds.size.width), height: CGFloat(30)))
        activityIndicator           = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.gray)
//        activityIndicator.color     = AppColor.AppTheme_Primary //UIColor.black
        noData.addSubview(activityIndicator)
        activityIndicator.center    = CGPoint(x: CGFloat(noData.frame.size.width / 2), y: CGFloat(noData.frame.size.height / 2))
        activityIndicator.startAnimating()
        noData.backgroundColor      = UIColor.clear
        noData.layer.cornerRadius   = 3
        return noData
    }
    
    func footerDismiss(tableView:UITableView) ->UIView?{
        hiddeActivityIndicator()
        return nil
    }
    
    //MARK: Hidde Activity
    func hiddeActivityIndicator() {
        if((activityIndicator) != nil){
            activityIndicator.isHidden = true
            activityIndicator.removeFromSuperview()
            
        }
    }
}
