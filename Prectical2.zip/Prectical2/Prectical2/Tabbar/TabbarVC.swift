//
//  TabbarVC.swift
//  Prectical2
//
//  Created by Apple on 24/09/17.
//  Copyright © 2017 Apple. All rights reserved.
//

import UIKit

class TabbarVC: UITabBarController {

    @IBOutlet var IBTabHome: UITabBarItem!          = UITabBarItem()
    @IBOutlet var IBTabPost: UITabBarItem!          = UITabBarItem()
    @IBOutlet var IBTabCategory: UITabBarItem!       = UITabBarItem()
    @IBOutlet var IBTabMap: UITabBarItem!       = UITabBarItem()
    
    
    lazy var selectTab: Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()

        self.setView()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}



//MARK: setView
extension TabbarVC {
    
    func setView() {
        
        UITabBarItem.appearance().setTitleTextAttributes([NSForegroundColorAttributeName: UIColor.lightGray], for: .normal)
        UITabBarItem.appearance().setTitleTextAttributes([NSForegroundColorAttributeName: UIColor.blue], for: .selected)
        
        let objDashboardVC = UserListVC(nibName: "UserListVC", bundle: nil)
        objDashboardVC.IsFromTabbar = true
        objDashboardVC.title = "PostList"
        self.IBTabHome.title = "Posts"
//        self.IBTabHome.image = UIImage(named: TabbarImage.Home_unselect)?.withRenderingMode(.alwaysOriginal)
//        self.IBTabHome.selectedImage = UIImage(named: TabbarImage.Home_select)?.withRenderingMode(.alwaysOriginal)
        objDashboardVC.tabBarItem = IBTabHome
        objDashboardVC.tabBarItem.tag = 1
        
        let objProductsVC = CategoryListVC(nibName: "CategoryListVC", bundle: nil)
        objProductsVC.title = "Category"
        self.IBTabCategory.title = "Category"
//        self.IBTabProducts.image = UIImage(named: TabbarImage.Product_unselect)?.withRenderingMode(.alwaysOriginal)
//        self.IBTabProducts.selectedImage = UIImage(named: TabbarImage.Product_select)?.withRenderingMode(.alwaysOriginal)
        objProductsVC.tabBarItem = IBTabCategory
        objProductsVC.tabBarItem.tag = 2
        
        let objPostsVC = MapVC(nibName: "MapVC", bundle: nil)
        objPostsVC.title = "Map View"
        self.IBTabMap.title = "Map View"
//        self.IBTabEnquiry.image = UIImage(named: TabbarImage.Enquiry_unselect)?.withRenderingMode(.alwaysOriginal)
//        self.IBTabEnquiry.selectedImage = UIImage(named: TabbarImage.Enquiry_select)?.withRenderingMode(.alwaysOriginal)
        objPostsVC.tabBarItem = IBTabMap
        objPostsVC.tabBarItem.tag = 3
        
        
        let navDashboradVC :UINavigationController = UINavigationController(rootViewController: objDashboardVC)
        let navProductsVC :UINavigationController = UINavigationController(rootViewController: objProductsVC)
        let navEnquireVC :UINavigationController = UINavigationController(rootViewController: objPostsVC)


        self.viewControllers = [navDashboradVC,navProductsVC,navEnquireVC]
        self.selectedIndex = selectTab
        self.delegate = self
        self.setViewControllers(self.viewControllers, animated: true)
        
        //New Changes
    }
    
    @IBAction func btnbrClick(_ sender: Any) {
        
        let objTabbarVC = ViewController(nibName: "ViewController", bundle: nil)
        appDelegate.window?.rootViewController = objTabbarVC
        appDelegate.window?.makeKeyAndVisible()
        
    }
}

//MARK:- UITabBarControllerDelegate Method
extension TabbarVC : UITabBarControllerDelegate {
    
    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
        return true
    }
}
