//
//  MapVC.swift
//  Prectical2
//
//  Created by Apple on 23/09/17.
//  Copyright © 2017 Apple. All rights reserved.
//

import UIKit
import MapKit

class MapVC: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
    
    @IBOutlet weak var objmapview: MKMapView!
    var locationManager:CLLocationManager!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager = CLLocationManager() //instantiate
        locationManager.delegate = self // set the delegate
        locationManager.desiredAccuracy = kCLLocationAccuracyBest // required accurancy
        locationManager.requestWhenInUseAuthorization() // request authorization
        locationManager.startUpdatingLocation()
        
        self.objmapview.delegate = self
        self.setView()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

extension MapVC {
    
    func setView() {
        
        self.setMapview()
    }
    
    func setMapview() {
        var mapRegion = MKCoordinateRegion()
        let coordinate = CLLocationCoordinate2D(latitude: 23.007201, longitude: 72.505406)
        mapRegion.center = coordinate
        mapRegion.span.latitudeDelta = 1.0
        mapRegion.span.longitudeDelta = 1.0
        self.objmapview.setRegion(mapRegion, animated: true)
        let annotation = MKPointAnnotation()
        annotation.coordinate = coordinate
        annotation.title = "Mitun"
        annotation.subtitle = "iOS Developer"
        self.objmapview.addAnnotation(annotation)
//        self.objmapview.showsUserLocation = true
        //23.007201
        //72.505406
    }
    
    /*
    func setMap(Latitude:Double, Longitude:Double) {
        
        let delayTime = dispatch_time(DISPATCH_TIME_NOW, Int64(1.0 * Double(NSEC_PER_SEC)))
        dispatch_after(delayTime, dispatch_get_main_queue()) {
            
            var mapRegion = MKCoordinateRegion()
            let Lat = Latitude
            let Long = Longitude
            let Coordinates = CLLocationCoordinate2D(latitude: Lat as CLLocationDegrees, longitude: Long as CLLocationDegrees)
            mapRegion.center = Coordinates;
            mapRegion.span.latitudeDelta    = 0.002;
            mapRegion.span.longitudeDelta   = 0.002;
            self.mapBusinessLocation.setRegion(mapRegion, animated: true)
            
            let annotation = MKPointAnnotation()
            annotation.coordinate = Coordinates
            annotation.title = ""
            annotation.subtitle = ""
            self.mapBusinessLocation.addAnnotation(annotation)
            
            /*
             if #available(iOS 9.0, *) {
             self.mapBusinessLocation.focused
             } else {
             // Fallback on earlier versions
             };
             */
        }
        
        /*
         // Map customization
         if #available(iOS 9.0, *) {
         self.mapBusinessLocation.showsTraffic = true
         } else {
         // Fallback on earlier versions
         }
         */
        self.mapBusinessLocation.delegate = self;
    }*/
}
