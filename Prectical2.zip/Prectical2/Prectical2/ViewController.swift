//
//  ViewController.swift
//  Prectical2
//
//  Created by Apple on 23/09/17.
//  Copyright © 2017 Apple. All rights reserved.
//

import UIKit
import Alamofire
import AlamofireObjectMapper
import ObjectMapper

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
//        self.navigationController?.navigationBar.isHidden = true
        self.navigationController?.navigationBar.isTranslucent = false
//        self.navigationController?.navigationBar.tintColor = UIColor.groupTableViewBackground
        self.title = "Home"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

extension ViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBAction func onClickButton (_ sender: UIButton) {
        
        switch sender.tag {
        case 10:
            //redirection TableList
            let objTableListVC = UserListVC(nibName: "UserListVC", bundle: nil)
            self.navigationController?.pushViewController(objTableListVC, animated: true)
            break
        case 20:
            //redirection TableList
            let objTableListVC = CategoryListVC(nibName: "CategoryListVC", bundle: nil)
            self.navigationController?.pushViewController(objTableListVC, animated: true)
            break
        case 30:
            //redirection TableList
            let objTabbarVC = TabbarVC(nibName: "TabbarVC", bundle: nil)
            appDelegate.window?.rootViewController = objTabbarVC
            appDelegate.window?.makeKeyAndVisible()
            break
        case 40:
            //redirection TableList
            let objTableListVC = MapVC(nibName: "MapVC", bundle: nil)
            self.navigationController?.pushViewController(objTableListVC, animated: true)
            break
        case 50:
            //redirection TableList
            let objTableListVC = OfflineUserVC(nibName: "OfflineUserVC", bundle: nil)
            self.navigationController?.pushViewController(objTableListVC, animated: true)
            break
        case 60:
            //redirection TableList
            let objTableListVC = CollectionVC(nibName: "CollectionVC", bundle: nil)
            self.navigationController?.pushViewController(objTableListVC, animated: true)
            break
        case 70:
            
            self.openActionsheet()
            break
        case 80:
            
            self.DownloadDoc()
            break
        default:
            print("No rection")
        }
    }
    
    func openActionsheet() {
        
        let actionSheetDocument: UIAlertController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        actionSheetDocument.view.tintColor = AppColor.AppTheme_Primary
        let cancelActionButton: UIAlertAction = UIAlertAction(title: "Cancel", style: .cancel) { void in
            //            print("Cancel")
        }
        let alertDeviceAction: UIAlertAction = UIAlertAction(title: "Camera", style: .default) { void in
            print("From Device")
            self.openCamera()
        }
        let alertRepositoryAction: UIAlertAction = UIAlertAction(title: "Gallery", style: .default) { void in
            print("Add from Repository")
            self.openGallary()
        }
        actionSheetDocument.addAction(cancelActionButton)
        actionSheetDocument.addAction(alertDeviceAction)
        actionSheetDocument.addAction(alertRepositoryAction)
        self.present(actionSheetDocument, animated: true, completion: nil)
    }
    
    func openCamera(){
        
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerControllerSourceType.camera;
            self.present(imagePicker, animated: true, completion: nil)
        }
        else {
            let alert:UIAlertController=UIAlertController(title: "Oops No Camera !", message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
            let gallaryAction = UIAlertAction(title: "Gallary", style: UIAlertActionStyle.default) {
                UIAlertAction in
                self.openGallary()
            }
            let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.destructive) {
                UIAlertAction in
            }
            // Add the actions
            alert.addAction(gallaryAction)
            alert.addAction(cancelAction)
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func openGallary(){
        
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.photoLibrary) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerControllerSourceType.photoLibrary;
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]){
        
        picker .dismiss(animated: true, completion: nil)
        if let imagePicked = info[UIImagePickerControllerEditedImage] as? UIImage {
            self.redirecttoUpload(image: imagePicked)
        }else if let imagePicked = info[UIImagePickerControllerOriginalImage] as? UIImage {
            self.redirecttoUpload(image: imagePicked)
            
        }
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController){
        picker .dismiss(animated: true, completion: nil)
    }
    
    func redirecttoUpload(image:UIImage) {
        
        let objTableListVC = UploadVC(nibName: "UploadVC", bundle: nil)
        objTableListVC.image = image
        self.navigationController?.pushViewController(objTableListVC, animated: true)
    }
    
    
    func DownloadDoc() {
        
        self.createDocumentFolder()
        
        self.imageDownLoad(fileUrl: "http://mvjadav.com.morecustomersapp.com/uploads/TempFiles/81/11da769f-8bac-4d27-97b4-b888cbb93a63-201709250050288550.jpeg", destinationPath: "DownloadImage/Test/IMG_0001.JPG") { (error, status, strpath) -> Void! in
            print(strpath)
        }
        

    }
    
    func imageDownLoad(fileUrl:String, destinationPath: String, ServiceCallBack: @escaping (_ error: NSError?, _ status:Bool?, _ resultPath: String?)-> Void!) {
        
        
        let destination: DownloadRequest.DownloadFileDestination = { _, _ in
            let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            let fileURL = documentsURL.appendingPathComponent(destinationPath)
            return (fileURL, [.removePreviousFile, .createIntermediateDirectories])
        }
        
        Alamofire.download(fileUrl, to: destination).response { response in
            print(response)
            
            if response.error == nil {
                ServiceCallBack(nil,true, response.destinationURL?.path)
            } else {
                ServiceCallBack(response.error as NSError?,false, nil)
            }
        }
    }
    
    func createDocumentFolder() {
        
        
        //selectContactNameandPhoneForDocument
        let fileManager = FileManager.default
        //create document id / path directory
        let MCRMDocumentID = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent("DownloadImage/Test")
        if !fileManager.fileExists(atPath: MCRMDocumentID){
            try! fileManager.createDirectory(atPath: MCRMDocumentID, withIntermediateDirectories: true, attributes: nil)
        }else{
            print("Already dictionaryID folder created.")
        }
    }
    
    func IsDocumentFileExist(strPath:String) -> Bool {
        
        let filePath = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent(strPath)
        if FileManager.default.fileExists(atPath: filePath){
            return true
        }else{
            return false
        }
        
    }
    
}

