//
//  serviceDataModel.swift
//  Prectical2
//
//  Created by Apple on 24/09/17.
//  Copyright © 2017 Apple. All rights reserved.
//

import Foundation
import ObjectMapper

class PostsRequestModel<T: Mappable>: Mappable {
    
    lazy var PageSize           : Int   = 0
    lazy var PageIndex          : Int   = 0
    var SearchParams            : T?
    
    required init(){
        //SiteID = Preference.GetInteger(key : UserDefaultsKey.SiteID)
    }
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        PageSize                            <- map["PageSize"]
        PageIndex                           <- map["PageIndex"]
        SearchParams                        <- map["SearchParams"]
    }
}
class SearchParams: Mappable {
    lazy var SearchText : String?       = ""
    lazy var IsRead : Int?              = 0
    lazy var SiteID : Int?              = 0
    
    required init(){
        self.IsRead = 0
        SiteID = 77
    }
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        SearchText          <- map["SearchText"]
        IsRead              <- map["IsRead"]
        SiteID              <- map["SiteID"]
    }
}

class PostModel<T: Mappable>: Mappable {
    
    lazy var CurrentPage            : Int   = 0
    lazy var TotalPage              : Int   = 0
    lazy var TotalItems             : Int   = 0
    lazy var ItemsPerPage           : Int   = 0
    lazy var Context                : Int   = 0
    lazy var Items                  : [T]?  = []
    
    required init(){
    }
    
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        CurrentPage                 <- map["CurrentPage"]
        TotalPage                   <- map["TotalPage"]
        TotalItems                  <- map["TotalItems"]
        ItemsPerPage                <- map["ItemsPerPage"]
        Context                     <- map["Context"]
        Items                       <- map["Items"]
    }
}

class PostDetail : Mappable {
    
    lazy var SiteNotificationID         : Int   = 0
    lazy var Description                : String? = ""
    lazy var CategoryName               : String? = ""
    lazy var NotificationType           : CLong? = 0
    lazy var ViewMoreText               : String? = ""
    lazy var SubCategoryName            : String? = ""
    lazy var Image                      : String? = ""
    lazy var PostImagePath              : String? = ""
    lazy var Date                       : String? = ""
    lazy var Count                      : Int   = 0
    lazy var Row                        : Int   = 0
    lazy var ViewCount                  : Int?   = 0
    lazy var RedirectUrl                : String? = ""
    //CategoryID
    //CreatedBy
    
    
    required init(){
    }
    
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        SiteNotificationID              <- map["SiteNotificationID"]
        Description                     <- map["Description"]
        NotificationType                <- map["NotificationType"]
        ViewMoreText                    <- map["ViewMoreText"]
        CategoryName                    <- map["CategoryName"]
        SubCategoryName                 <- map["SubCategoryName"]
        Image                           <- map["Image"]
        PostImagePath                   <- map["PostImagePath"]
        Date                            <- map["Date"]
        Count                           <- map["Count"]
        Row                             <- map["Row"]
        ViewCount                       <- map["ViewCount"]
        RedirectUrl                       <- map["RedirectUrl"]
    }
    
}


class ProductItems : Mappable{
    
    lazy var ProductID                          : Int? = 0
    lazy var ProductName                        : String? = ""
    lazy var ShortDescription                   : String? = ""
    lazy var PriceRange                         : Int? = 0
    lazy var Price1                             : Int? = 0
    lazy var Price2                             : Int? = 0
    
    lazy var StrikePrice1                       : Int? = 0
    lazy var StrikePrice2                       : Int? = 0
    lazy var FullImagePath                      : String? = ""
    lazy var Slug                               : String? = ""
    lazy var ProductUrl                         : String? = ""
    
    lazy var Row                                : Int? = 0
    lazy var Count                              : Int? = 0
    lazy var SiteVisitorWishListID              : Int? = 0
    lazy var ViewCount                          : Int? = 0
    
    lazy var IsActive                           : Bool? = false
    
    lazy var Discount                           : Int? = 0
    lazy var CategoryName                       : String? = ""
    lazy var SubCategoryName                    : String? = ""
    lazy var CreatedDate                        : String? = ""
    lazy var IsSelected                        : Bool? = false
    
    required init(){
        
    }
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        
        ProductID                       <- map["ProductID"]
        ProductName                     <- map["ProductName"]
        ShortDescription                <- map["ShortDescription"]
        PriceRange                      <- map["PriceRange"]
        Price1                          <- map["Price1"]
        Price2                          <- map["Price2"]
        
        StrikePrice1                    <- map["StrikePrice1"]
        StrikePrice2                    <- map["StrikePrice2"]
        FullImagePath                   <- map["FullImagePath"]
        Slug                            <- map["Slug"]
        Row                             <- map["Row"]
        Count                           <- map["Count"]
        SiteVisitorWishListID           <- map["SiteVisitorWishListID"]
        ViewCount                       <- map["ViewCount"]
        IsActive                        <- map["IsActive"]
        Discount                        <- map["Discount"]
        CategoryName                    <- map["CategoryName"]
        SubCategoryName                 <- map["SubCategoryName"]
        CreatedDate                     <- map["CreatedDate"]
        IsSelected                      <- map["IsSelected"]
        ProductUrl                      <- map["ProductUrl"]
    }
}


class CategoryList<T: Mappable>: Mappable {
    
    lazy var Name               : String   = ""
    lazy var SubCategory        : [T]?  = []
    
    required init(){
    }
    
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        Name                 <- map["Name"]
        SubCategory                   <- map["SubCategory"]
    }
}

class SubCategoryList: Mappable {
    
    lazy var Name               : String   = ""
    
    required init(){
    }
    
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        Name                 <- map["Name"]
    }
}


class UserModel: Mappable {
    
    lazy var userId             : CLong? = 0
    lazy var user_name          : String? = ""
    lazy var number             : String? = ""
    lazy var address            : String? = ""
    lazy var gender             : String? = ""
    
    
    required init(){ }
    required init?(map: Map) { }
    
    func mapping(map: Map) {
        
        userId              <- map["userId"]
        user_name           <- map["user_name"]
        number              <- map["number"]
        address             <- map["address"]
        gender              <- map["gender"]
    }
}

class ProductImageModel: Mappable{
    
    lazy var ProductImageID         : Int? = 0
    lazy var SortOrder              : Int? = 0
    lazy var FullImagePath          : String? = ""
    lazy var ImagePath              : String? = ""
    
    required init(){
    }
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        
        ProductImageID          <- map["ProductImageID"]
        SortOrder               <- map["SortOrder"]
        FullImagePath           <- map["FullImagePath"]
        ImagePath               <- map["ImagePath"]
    }
}
