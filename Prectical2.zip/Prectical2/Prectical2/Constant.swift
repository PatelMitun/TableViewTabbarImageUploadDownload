//
//  Constant.swift
//  Prectical2
//
//  Created by Apple on 24/09/17.
//  Copyright © 2017 Apple. All rights reserved.
//

import Foundation
import AlamofireObjectMapper
import ObjectMapper

let appDelegate = UIApplication.shared.delegate as! AppDelegate


struct serviceURL {
    
    static let Domain = "http://admin.morecustomersapp.com"           //admin
    
    static let Base = Domain+"/siteadminapp/api"
    
    static let PostList                     = Base + "/notification/getpostlist"

}

struct AppImageName {
    
    static let Img_Placeholder_Post     = "ic_Placeholder_Post"
    
}

struct AppMessage {
    
    static let SyncFail                     = "App is not synced properly. Please retry."
    static let RequestFail                  = "Network error, please try after some time."
    static let NoInternetConnection         = "No internet connection found. Please restart app with internet connection."
}

struct AppColor {
    
    //App Theme Status Bar
    static let Statusbar_Primary        = UIColor(red: 105/255, green: 198/255, blue: 192/255, alpha: 0.7)
    
    //App Theme
    static let AppTheme_Primary         = UIColor(red: 105/255, green: 198/255, blue: 192/255, alpha: 1.0)
    static let AppTheme_Secondary       = UIColor(red: 255/255, green: 51/255, blue: 102/255, alpha: 0.5)
    
    static let Dark_Pink_Secondary = UIColor(red: 255/255, green: 51/255, blue: 102/255, alpha: 0.5)
    static let Dark_Blue        = UIColor(red: 62/255, green: 75/255, blue: 94/255 , alpha :1)
    static let Dark_Black       = UIColor(red: 24/255, green: 25/255, blue: 27/255 , alpha :1.0)
    static let Dark_Pink        = UIColor(red: 255/255, green: 51/255, blue: 102/255, alpha: 1.0)
    static let Dark_Green       =  UIColor(red: 68/255, green: 175/255, blue: 86/255 , alpha :1.0)
    static let Dark_Orange      =  UIColor(red: 209/255, green: 92/255, blue: 50/255, alpha: 1.0)
    static let Dark_Gray        = UIColor(red: 67/255, green: 65/255, blue: 73/255 , alpha :1)
    
    //General Light Color
    static let Light_Grey       = UIColor(red: 170/255, green: 170/255, blue: 170/255, alpha: 0.5)
    
    
    static let Red              = UIColor.red
    static let Green            = UIColor(red: 41/255, green: 169/255, blue: 88/255, alpha: 1.0)
    
    static let ToastGreenColor        = UIColor(red: 39/255, green: 174/255, blue: 96/255 , alpha :1)
    static let WhatsAppColor        = UIColor(red: 89/255, green: 154/255, blue: 30/255 , alpha :1)
}

class Common {
    
    
    func setNavigationBarTitle(title:String, subtitle:String) -> UIView {
        
        let titleLabel = UILabel(frame: CGRect(x: 0, y: -2, width: 0, height: 0))
        //        let titleLabel = UILabel(frame: cgRectMake(0, -2, 0, 0))
        
        titleLabel.backgroundColor = UIColor.clear
        titleLabel.textColor = UIColor.black    //UIColor.white
        titleLabel.font = UIFont.boldSystemFont(ofSize: 14)
        titleLabel.text = title
        titleLabel.sizeToFit()
        
        let subtitleLabel = UILabel(frame: CGRect(x: 0, y: 18, width: 0, height: 0))
        subtitleLabel.backgroundColor = UIColor.clear
        subtitleLabel.textColor = UIColor.darkGray  //UIColor.groupTableViewBackground
        subtitleLabel.font = UIFont.systemFont(ofSize: 12)
        subtitleLabel.text = subtitle
        subtitleLabel.sizeToFit()
        
        let titleView = UIView(frame: CGRect(x: 0, y: 0, width: max(titleLabel.frame.size.width, subtitleLabel.frame.size.width), height: 30))
        titleView.backgroundColor = UIColor.clear
        titleView.addSubview(titleLabel)
        titleView.addSubview(subtitleLabel)
        
        let widthDiff = subtitleLabel.frame.size.width - titleLabel.frame.size.width
        
        //        if widthDiff > 0 {
        //            var frame = titleLabel.frame
        //            frame.origin.x = widthDiff / 2
        //        } else {
        //            var frame = subtitleLabel.frame
        //            frame.origin.x = abs(widthDiff) / 2
        //            titleLabel.frame = frame.integral
        //        }
        
        if widthDiff < 0 {
            let newX = widthDiff / 2
            subtitleLabel.frame.origin.x = abs(newX)
        } else {
            let newX = widthDiff / 2
            titleLabel.frame.origin.x = newX
        }
        
        
        return titleView
    }
    
    /*
     
    func setDocImagePath(strImageName:String, ExtentionType:String, originalPath:URL) -> String {
        
        var strdocName = ""
        if let strName = objContactDetailModel.Name {
            strdocName = strName
        }
        if let phoneNumber = objContactDetailModel.Phone1 {
            strdocName = strdocName + "_\(phoneNumber)"
        }
        
        var fileName = ""
        
        if (self.IBtxtDocName.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).isEmpty)! {
            fileName = self.getImageName(Extention: ExtentionType)
        }else {
            fileName = (self.IBtxtDocName.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines))!
            fileName = fileName + "." + ExtentionType
        }
        
        let fileManager = FileManager.default
        
        //create document directory
        let MCRMDocument = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent(DocumentsDirectory.ducumentDireName)
        if !fileManager.fileExists(atPath: MCRMDocument){
            try! fileManager.createDirectory(atPath: MCRMDocument, withIntermediateDirectories: true, attributes: nil)
        }else{
            print("Already dictionary created.")
        }
        
        //create document id / path directory
        let MCRMDocumentID = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent(DocumentsDirectory.ducumentDireName+"/\(strdocName)")
        if !fileManager.fileExists(atPath: MCRMDocumentID){
            try! fileManager.createDirectory(atPath: MCRMDocumentID, withIntermediateDirectories: true, attributes: nil)
        }else{
            print("Already dictionaryID folder created.")
        }
        
        //create Image into folder
        let paths = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent("\(DocumentsDirectory.ducumentDireName)/\(strdocName)/"+fileName)
        
        do {
            let data = try Data(contentsOf: originalPath, options: .dataReadingMapped)
            print(data)
            fileManager.createFile(atPath: paths as String, contents: data, attributes: nil)
        } catch {
            print(error)
        }
        return "\(DocumentsDirectory.ducumentDireName)/\(strdocName)/"+fileName
    }
    
    
    
    func clearAllTempFileFromDirectory(){
        
        let tempDirPath = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent("\(DocumentsDirectory.ducumentDireName)/Temp")
        let fileManager = FileManager.default
        // Delete 'subfolder' folder
        do {
            try fileManager.removeItem(atPath: tempDirPath)
        }
        catch let error as NSError {
            print("Ooops! Something went wrong: \(error)")
        }
    }
    
    func getFileExtention(strImagePath:URL) -> String {
        
        var strExtention = ""
        let imgLastName = strImagePath.lastPathComponent
        if imgLastName != "" {
            
            let aryName = imgLastName.components(separatedBy: ".")
            if aryName.count > 0 {
                for i in 0..<aryName.count{
                    if i == aryName.count-1 {
                        strExtention = aryName[i]
                    }
                }
            }
        }
        return strExtention
    }
    
     
     */
    
}

//MARK:- String Validate
extension String {
    
    
    var isEmptyField: Bool {
        return trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines) == ""
    }
}

//service Request Data
class ServiceRequest<T: Mappable>: Mappable {
    
    var Key: String?
    var Token: String?
    var Slug: String?
    var Data : T?
    
    init() {
        
        
        Token = "d5be5ea7-71a7-4307-b9ea-96fd8e672dc0"
        Key = "SiteAdminAppkey"
        Slug = ""
    }
    
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        
        Key         <- map["Key"]
        Token      <- map["Token"]
        Slug      <- map["Slug"]
        Data       <- map["Data"]
        
    }
}

class ServiceRequestModel: Mappable {
    
    var Key: String?
    var Token: String?
    var Slug: String?
    
    
    init() {
        Token = "d5be5ea7-71a7-4307-b9ea-96fd8e672dc0"
        Key = "SiteAdminAppkey"
        Slug = ""
    }
    
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        
        Key         <- map["Key"]
        Token      <- map["Token"]
        Slug      <- map["Slug"]
    }
}

class ServiceRequestArray<T: Mappable>: Mappable {
    
    var Key: String?
    var Token: String?
    var Slug: String?
    
    
    var Data : [T]?
    
    init() {
        
        Token = "d5be5ea7-71a7-4307-b9ea-96fd8e672dc0"
        Key = "SiteAdminAppkey"
        Slug = ""
    }
    
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        
        Key         <- map["Key"]
        Token      <- map["Token"]
        Slug      <- map["Slug"]
        Data       <- map["Data"]
    }
}

class ServiceResponse<T: Mappable>: Mappable {
    
    var IsSuccess: Bool?
    var Code: String?
    var Message: String? = ""
    var Data: T?
    
    init?() {
        
    }
    required init?(map: Map) {
        
    }
    
    // Mappable
    func mapping(map: Map) {
        IsSuccess       <- map["IsSuccess"]
        Code            <- map["Code"]
        Message         <- map["Message"]
        Data            <- map["Data"]
        
    }
}

class ServiceResponseArray<T: Mappable>: Mappable {
    
    var IsSuccess       : Bool?
    var Code            : String?
    var Message         : String?
    lazy var Data            : [T]? = []
    
    init?() {
        
    }
    required init?(map: Map) {
        
    }
    
    // Mappable
    func mapping(map: Map) {
        IsSuccess    <- map["IsSuccess"]
        Code         <- map["Code"]
        Message      <- map["Message"]
        Data       <- map["Data"]
        
    }
}

class ServiceResponseMessage: Mappable, CustomStringConvertible {
    
    var IsSuccess           : Bool? = false
    var Code                : String? = ""
    var Message             : String? = ""
    
    init?() {
        
    }
    required init?(map: Map) {}
    
    var description: String {
        get {
            return Mapper().toJSONString(self, prettyPrint: false)!
        }
    }
    // Mappable
    func mapping(map: Map) {
        IsSuccess    <- map["IsSuccess"]
        Code         <- map["Code"]
        Message      <- map["Message"]
    }
}

class ServiceResponsewithError<T: Mappable, E: Mappable>: Mappable {
    
    var IsSuccess: Bool?
    var Code: Int?
    var Message: String?
    var Data: T?
    var Errors: [E]?
    
    init?() {
        
    }
    required init?(map: Map) {
        
    }
    
    // Mappable
    func mapping(map: Map) {
        IsSuccess    <- map["IsSuccess"]
        Code         <- map["Code"]
        Message      <- map["Message"]
        Data       <- map["Data"]
        Errors       <- map["Errors"]
        
    }
}


//Model Name
struct CustomModelName {
    
    //Contact Screen
    static let Data = "Data"
}
