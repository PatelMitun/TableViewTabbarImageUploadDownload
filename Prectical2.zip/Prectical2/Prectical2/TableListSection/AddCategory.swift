//
//  AddCategory.swift
//  Prectical2
//
//  Created by Apple on 24/09/17.
//  Copyright © 2017 Apple. All rights reserved.
//

import UIKit

@objc protocol AddCategoryDelegate:class {
    @objc optional func didFinishAddTask(title : String,index : Int,isHeader : Bool)
}


class AddCategory: UIViewController {

    @IBOutlet var IBbarbtnBack                      : UIBarButtonItem!
    @IBOutlet var IBbarbtnDone                      : UIBarButtonItem!
    @IBOutlet weak var IBtxtTitle                   : UITextField!
    
    var index : Int             = 0
    var isHeader : Bool         = false
    weak var delegate:AddCategoryDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setView()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        self.view.endEditing(true)
        super.viewDidDisappear(true)
    }

}


//MARK: - Other Methods
extension AddCategory {
    
    func setView() {
        
        if isHeader {
            self.title = "Add Header"
        }else {
            self.title = "Add Row"
        }
        
        self.navigationItem.leftBarButtonItem       = IBbarbtnBack
        self.navigationItem.rightBarButtonItem     = IBbarbtnDone
    }
    
}

//MARK: - IBAction methods
extension AddCategory {
    
    @IBAction func btnClickAddHeaderBack(_ sender: AnyObject) {
        _ =  self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnClickAddHeaderDone(_ sender: AnyObject) {
        
        if (IBtxtTitle.text?.isEmpty)! {}else {
            self.delegate?.didFinishAddTask!(title: self.IBtxtTitle.text!, index: self.index, isHeader: self.isHeader)
            _ =  self.navigationController?.popViewController(animated: true)
        }
        
    }
    
}
