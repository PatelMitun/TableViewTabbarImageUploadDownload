//
//  CategoryListVC.swift
//  Prectical2
//
//  Created by Apple on 23/09/17.
//  Copyright © 2017 Apple. All rights reserved.
//

import UIKit
import ObjectMapper

class CategoryListVC: UIViewController {

    @IBOutlet weak var tblList: UITableView!
    @IBOutlet weak var btnbarAdd: UIBarButtonItem!
    
    var objCategoryList:[CategoryList<SubCategoryList>] = []
    
    var mysection:[SectionData] = {
        let section1 = SectionData(title: "Months", data: "January", "February", "March", "April", "May", "June")
        let section2 = SectionData(title: "Days", data: "Monday", "TuesDay", "WednesDay")
        return [section1, section2]
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.setView()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}


extension CategoryListVC {
    
    func setView() {
        self.setdefaultValue()
        self.navigationItem.rightBarButtonItem = self.btnbarAdd
        self.tblList.tableFooterView = UIView()
        
    }
    func setdefaultValue() {
        
        let objTemo = CategoryList<SubCategoryList>()
        objTemo.Name = "Month"
        var objRow : [SubCategoryList] = []
        
        let rowModel = SubCategoryList()
        rowModel.Name = "Jan"
        objRow.append(rowModel)
        
        let rowModel1 = SubCategoryList()
        rowModel1.Name = "Feb"
        objRow.append(rowModel)
        
        let rowModel2 = SubCategoryList()
        rowModel2.Name = "March"
        objRow.append(rowModel)
        
        let rowModel3 = SubCategoryList()
        rowModel3.Name = "Apr"
        objRow.append(rowModel)
        
        
        let rowModel4 = SubCategoryList()
        rowModel4.Name = "May"
        objRow.append(rowModel)
        
        objTemo.SubCategory = objRow
        self.objCategoryList.append(objTemo)
    }
}

//MARK: - IBAction methods
extension CategoryListVC {
    
    @IBAction func btnClickAddHeader(_ sender: AnyObject) {
        
        let objHeaderDetailVC                   = AddCategory(nibName: "AddCategory", bundle: nil)
        objHeaderDetailVC.delegate              = self
        objHeaderDetailVC.isHeader              = true
        self.navigationController?.pushViewController(objHeaderDetailVC, animated: true)
    }
    
}


extension CategoryListVC: UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return objCategoryList.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let frame: CGRect = tableView.frame
        
        // Text Title
        let lbl : UILabel = UILabel(frame: CGRect(x: 5, y: 0, width: 150, height: 50))
        lbl.text = objCategoryList[section].Name
        lbl.textColor = UIColor.white
        
        //Add Button
        let DoneBut: UIButton = UIButton(frame: CGRect(x: frame.size.width - 50, y: 0, width: 50, height: 50)) //
        DoneBut.setTitle("+", for: .normal)
        DoneBut.backgroundColor = UIColor.lightGray
        DoneBut.tag = section
        DoneBut.addTarget(self, action:#selector(buttonTapped(sender:)), for: .touchUpInside)
        DoneBut.backgroundColor = UIColor.lightGray
        
        let headerView: UIView = UIView(frame: CGRect(x: 0, y: 0, width: frame.size.width, height: frame.size.height))
        headerView.backgroundColor = UIColor.lightGray
        headerView.addSubview(lbl)
        headerView.addSubview(DoneBut)
        return headerView
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return objCategoryList[section].numberOfItems
        return (objCategoryList[section].SubCategory?.count)!

    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "Cell")
        cell.selectionStyle = .none
//        cell.textLabel?.text = self.mysection[indexPath.section][indexPath.row]
        cell.textLabel?.text = self.objCategoryList[indexPath.section].SubCategory?[indexPath.row].Name

        return cell
    }
    
    
    
    func buttonTapped(sender: UIButton) {
        //Button Tapped and open your another ViewController
        
        let objHeaderDetailVC                   = AddCategory(nibName: "AddCategory", bundle: nil)
        objHeaderDetailVC.delegate              = self
        objHeaderDetailVC.index                 = sender.tag
        self.navigationController?.pushViewController(objHeaderDetailVC, animated: true)
        
    }
    
    
}

extension CategoryListVC: AddCategoryDelegate {
    
    func didFinishAddTask(title : String,index : Int,isHeader : Bool) {
        
        
        if isHeader {
            //var objRow : [Row] = []
            let objTemo = CategoryList<SubCategoryList>()
            objTemo.Name = title
            objTemo.SubCategory = []
            self.objCategoryList.append(objTemo)
        }else {
            let rowModel = SubCategoryList()
            rowModel.Name = title
            self.objCategoryList[index].SubCategory?.append(rowModel)
        }
        self.tblList.reloadData()
        
    }
}

//MARK: - Set Data Structure
struct SectionData {
    let title: String
    var data : [String]
    
    var numberOfItems: Int {
        return data.count
    }
    
    subscript(index: Int) -> String {
        return data[index]
    }
}

extension SectionData {
    //  Putting a new init method here means we can
    //  keep the original, memberwise initaliser.
    init(title: String, data: String...) {
        self.title = title
        self.data  = data
    }
}
