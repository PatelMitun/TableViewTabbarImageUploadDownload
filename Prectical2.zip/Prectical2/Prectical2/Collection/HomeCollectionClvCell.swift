//
//  HomeCollectionClvCell.swift
//  Way2Web
//
//  Created by Kaira NewMac on 1/20/17.
//  Copyright © 2017 Kaira NewMac. All rights reserved.
//

import UIKit

class HomeCollectionClvCell: UICollectionViewCell {
    
    @IBOutlet weak var IBimgCollection:UIImageView!
    @IBOutlet weak var IBlblTitle:UILabel!
    @IBOutlet weak var IBlblPrice:UILabel!
    @IBOutlet weak var IBbtnShare:UIButton!
    @IBOutlet weak var IBbtnCell:UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()

    }
    
    func setCustomCell(objModel:PostDetail) {
        
        if let strname = objModel.Description {
            self.IBlblTitle.text = strname
        }

        
        if let strImageUrl = objModel.PostImagePath, strImageUrl != "" {
            print(strImageUrl)
            self.IBimgCollection.setIndicatorStyle(.white)
            self.IBimgCollection.setShowActivityIndicator(true)
            self.IBimgCollection.sd_setImage(with: URL(string:strImageUrl), placeholderImage: UIImage(named: AppImageName.Img_Placeholder_Post))
        }
    }
    
}
