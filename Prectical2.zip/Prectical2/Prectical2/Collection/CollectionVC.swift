//
//  CollectionVC.swift
//  Prectical2
//
//  Created by Apple on 23/09/17.
//  Copyright © 2017 Apple. All rights reserved.
//

import UIKit
import ObjectMapper
import SDWebImage


class CollectionVC: UIViewController {
    
    
    
    @IBOutlet weak var IBClvCollection          : UICollectionView!
    
    var PageSize :Int                   = 100
    var PageIndex :Int                  = 1
    var objPostList:PostModel           = PostModel<PostDetail>()
    

    
    
    //MARK: View Controller Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.setView()
        self.getPostList(IsLoader: true, PageIndex: self.PageIndex)
        //For Reload Collection View
//        NotificationCenter.default.addObserver(forName: NSNotification.Name(rawValue: HomeVC.ReloadHomeScreen), object: nil, queue: OperationQueue.main) { (Notification) in
//            if Notification.name.rawValue == HomeVC.ReloadHomeScreen {
//                self.getHomeResposeFromDB()
//            }
//        }
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        //         self.hidesBottomBarWhenPushed = true
    }
}
//MARK: Other Method
extension CollectionVC {
    
    //setView
    
    func setView() {
        self.objPostList.Items = []
        
        IBClvCollection.register(UINib(nibName: "HomeCollectionClvCell", bundle: nil), forCellWithReuseIdentifier: "HomeCollectionClvCell")
        
    }
}



// MARK: - Collection DataSource, Data Delegate Method and Cell Click Event
extension CollectionVC : UICollectionViewDataSource,UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return (self.objPostList.Items?.count)!
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if collectionView == IBClvCollection {
            //            let picDimension: CGFloat = self.IBClvCollection.frame.size.width-16 / 2.0
            //            return CGSize(width: picDimension/2.05, height: 245)
            
            let picDimension: CGFloat = (self.IBClvCollection.frame.size.width-1) / 2.0
            return CGSize(width: picDimension, height: 245)
        }
        return CGSize(width: 0, height: 0)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "HomeCollectionClvCell", for: indexPath) as! HomeCollectionClvCell
        cell.IBbtnCell.superview?.tag = 2
        cell.IBbtnCell.tag = indexPath.row
        if let objItem = self.objPostList.Items?[indexPath.row] {
            cell.setCustomCell(objModel: objItem)
        }
        
        cell.IBbtnCell.addTarget(self, action: #selector(self.btnCellPressed(sender:)), for: .touchUpInside)
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print(indexPath)
        
//        let objProductDetailVC = ProductDetailVC(nibName: "\(AppConstant.AppThemeType)ProductDetailVC", bundle: nil)
//        if let ProductID:Int = self.objHomeGetModel?.Data?.CollectionListModel?[indexPath
//            .row].ProductID {
//            objProductDetailVC.ProductID = ProductID
//        }
//        objProductDetailVC.IsNavigation = .Home
//        objProductDetailVC.hidesBottomBarWhenPushed = true
//        self.navigationController?.pushViewController(objProductDetailVC, animated: true)
        
    }
    

    
    func btnCellPressed(sender: UIButton) {
        //        applyTouchLiftAnimation(collcetionType: sender.superview!.tag, row: sender.tag)
        
        let indexPath: IndexPath = IndexPath(row: sender.tag, section: 0)
        UIView.animate(withDuration: 0.1, delay: 0.0, options: .curveEaseInOut, animations: {
            
            if sender.superview?.tag == 2 {
                if let cell = self.IBClvCollection.cellForItem(at: indexPath) {
                    cell.transform = CGAffineTransform(scaleX: 0.97, y: 0.97)
                }
            }
            
        }, completion:{_ in
            
            if sender.superview?.tag == 2 {
                if let cell = self.IBClvCollection.cellForItem(at: indexPath) {
                    cell.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
                }
            }
            
            
            self.applyTouchLiftAnimation(collcetionType: sender.superview!.tag, row: sender.tag)
        })
        
    }
    
    func applyTouchLiftAnimation(collcetionType: Int, row: Int) {
        
        let indexPath: IndexPath = IndexPath(row: row, section: 0)
        
        UIView.animate(withDuration: 0.1, delay: 0.0, options: .curveEaseInOut, animations: {
            
            if collcetionType == 2 {
                if let cell = self.IBClvCollection.cellForItem(at: indexPath) {
                    cell.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
                }
            }
        }, completion:{_ in
            
            print("CollectionType: \(collcetionType) and IndexPath: \(indexPath)")
            
            
            if collcetionType == 2 {
                //"Collection"
//                let objProductDetailVC = ProductDetailVC(nibName: "\(AppConstant.AppThemeType)ProductDetailVC", bundle: nil)
//                if let ProductID:Int = self.objHomeGetModel?.Data?.CollectionListModel?[indexPath
//                    .row].ProductID {
//                    objProductDetailVC.ProductID = ProductID
//                }
//                objProductDetailVC.IsNavigation = .Home
//                objProductDetailVC.hidesBottomBarWhenPushed = true
//                self.navigationController?.pushViewController(objProductDetailVC, animated: true)
                
            }
        })
    }
    
    
    
    
    //Alert Function
    func AlertMessage(msg:String){
        
        let alertController = UIAlertController(title: "Action", message: msg, preferredStyle: UIAlertControllerStyle.alert)
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default) { (result : UIAlertAction) -> Void in
        }
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }
}


//MARK: Service Call
extension CollectionVC {
    
    
    func getPostList(IsLoader:Bool? = true,PageIndex : Int){
        
        let objPostsRequest                 = PostsRequestModel<SearchParams>()
        objPostsRequest.PageIndex           = PageIndex
        objPostsRequest.PageSize            = self.PageSize
        let objSearchParams                 = SearchParams()
        //        objSearchParams.SiteID              = Preference.GetInteger(key : UserDefaultsKey.SiteID)
        objPostsRequest.SearchParams        = objSearchParams
        
        
        let objwebservice = webService()
        objwebservice.getPostList(objPostsRequestModel: objPostsRequest, IsLoader: true, viewController: self) { (response, IsSuccess) -> Void in
            if IsSuccess! {
                if let objData = response, let objserviceData = objData.Data {
                    self.objPostList = objserviceData
                    self.IBClvCollection.reloadData()
                }
            }
        }
    }

    
    
}
